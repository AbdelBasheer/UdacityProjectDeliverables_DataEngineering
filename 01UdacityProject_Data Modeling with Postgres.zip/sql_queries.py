# DROP TABLES
# List of Tables to Drop (if exists)
drop_table_queries = ["FactSongPlays", "DimUsers", "DimSongs", "DimArtists", "DimTime"]


# CREATE TABLES
FactSongplay_table_create = ("""CREATE TABLE IF NOT EXISTS FactSongPlays (songplay_id SERIAL PRIMARY KEY, start_time timestamp, sgkeyuser_id int, sgkeysong_id int, sgkeyartist_id int, session_id int, location varchar, user_agent varchar,  level varchar);""")

DimSong_table_create = ("""CREATE TABLE IF NOT EXISTS DimSong (sgkeySong_id SERIAL PRIMARY KEY, song_id varchar, title varchar, artist_id varchar, yearz int, duration real);""")

DimUser_table_create = ("""CREATE TABLE IF NOT EXISTS DimUser (sgkeyUserID SERIAL PRIMARY KEY, user_id varchar , first_name varchar, last_name varchar, gender varchar, level varchar);""")

DimArtist_table_create = ("""CREATE TABLE IF NOT EXISTS DimArtist (sgkeyArtist_id SERIAL PRIMARY KEY, artist_id varchar, name varchar, location varchar, latitude real, longitude real);""")

DimTime_table_create = ("""CREATE TABLE IF NOT EXISTS DimTime (sgkeyTimeID SERIAL PRIMARY KEY, start_time timestamp , hour int, day varchar, week varchar, month int, year int, weekday varchar);""")


create_table_queries = [FactSongplay_table_create, DimUser_table_create, DimSong_table_create, DimArtist_table_create, DimTime_table_create]

