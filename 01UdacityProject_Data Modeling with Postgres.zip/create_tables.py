#!/usr/bin/env python
# coding: utf-8

import psycopg2
import sql_queries

def create_database(cur, conn):    
    
    cur.execute('DROP DATABASE IF EXISTS sparkifydb;')
    cur.execute('CREATE DATABASE sparkifydb')
    
    return cur, conn

def drop_tables(cur, conn):
    for query in sql_queries.drop_table_queries:
        cur.execute("DROP TABLE IF EXISTS " + query)
        conn.commit()

def create_tables(cur, conn):
    for query in sql_queries.create_table_queries:
        cur.execute(query)
        conn.commit()

def main():
    
    #######################     CREATE DATABASE     #######################################################
    
    # connect to postgres database
    conn = psycopg2.connect("dbname=postgres user=postgres password=Hinati2015 host=localhost port=5433")
    conn.set_session(autocommit=True)
    
    #Activate connection server
    cur = conn.cursor()

    currr, connnn = create_database(cur, conn)
    
    cur.close()
    print(cur)
    print(conn)
    
    #######################  DROP TABLES /// CREATE TABLES  ##############################################
    
    # connect to sparkify database
    conn = psycopg2.connect("dbname=sparkifydb user=postgres password=Hinati2015 host=localhost port=5433")    
    cur = conn.cursor()
    
    #Activate connection server
    cur = conn.cursor()    
    
    drop_tables(cur, conn)
    create_tables(cur, conn)
    cur.close()
    
    print(cur)
    print(conn)